package myAudiLibrary.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyAudiLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyAudiLibraryApplication.class, args);
	}

}
